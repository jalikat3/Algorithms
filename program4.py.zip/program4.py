class Element():
    def __init__(self,value,direction):
        self.value=value
        self.direction=direction

    # note: I have not tested this yet, I saw that I had in
    # wrong place in office hours
    def changeDirection(self):
        self.direction=self.direction*-1

class Permutation():
    def __init__(self,array):
        self.array=array
        
    def isMobile(self, position):
        left=True
        right=True
        element=self.array[position]

        # if position is 0, there is no left element
        if position>0:
            elementLeft=self.array[position-1]
        else:
            left=False

        # if position is the length of the array-1,
        # there is no right position
        if position>=len(self.array)-1:
            right=False
        else:
            elementRight=self.array[position+1]
        
        # if there is an element to the right, the current element points right,
        # and the element's value is greater than the element on the right
        if (right==True and (element.direction==1 and element.value>elementRight.value)):
            return True

        # if there is an element to the left, the current element points left,
        # and the element's value is greater than the element on the left
        elif (left==True and (element.direction==-1 and element.value>elementLeft.value)):
            return True
        else:
            return False
        
    def anyMobile(self):
        
        for i in range(len(self.array)):
        
            if(self.isMobile(i)==True):
                return True
        return False
    
    def largestMobile(self):

        mobile=0
        isMobile=self.isMobile(0)
        for i in range(len(self.array)):
            if self.isMobile(i) and self.array[i].value>self.array[mobile].value:
                mobile=i
                isMobile=True
            
        if isMobile==True:        
            return mobile
        else:
            return "no mobile found"

    def nextPermutation(self):
        if(self.anyMobile()):
            mobilePosition=self.largestMobile()
        
        else:
            return False
        
        #mobile=0
        #for i in range(len(self.array)):
         #   if self.isMobile(i) and self.array[i].value>self.array[mobile].value:
         #       mobile=i
            
                
        #if self.isMobile(mobile)==False:
        #    return False
         
        returnArray=[]
        #print(type(mobilePosition))
        element=self.array[mobilePosition]
        
        if (element.direction==1):

            temp=element
            self.array[mobilePosition]=self.array[mobilePosition+1]
            self.array[mobilePosition+1]=temp
            
        elif (element.direction==-1):

            temp=element
            self.array[mobilePosition]=self.array[mobilePosition-1]
            self.array[mobilePosition-1]=temp
            

        
            
        for i in range(len(self.array)):
            returnArray.append(self.array[i].value)

        return Permutation(returnArray)
            
        
        
            
#def changeDirection(element):
#    element.direction=element.direction*(-1)

def testChangeDirection():
    element=Element(1, -1)
    changeDirection(element)
    print("Given a direction of -1, switch direction.")
    print("Direction is now: ")
    print(element.direction)
    element2=Element(2,1)
    changeDirection(element2)
    print("Given a direction of 1, switch direction.")
    print("Direction is now: ")
    print(element2.direction)

def testPermInitializer():

    # first array: 1 (left) False 2 (right) False 3 (left) True 4(right) False
    array1=[Element(1, -1), Element(2, 1), Element(3, -1), Element(4, 1)]
    permutation=Permutation(array1)
    
    print(permutation.array[0].value)
    print(permutation.array[0].direction)
    print(permutation.array[1].value)
    print(permutation.array[1].direction)
    print(permutation.array[2].value)
    print(permutation.array[2].direction)
    print(permutation.array[3].value)
    print(permutation.array[3].direction)

    # second array: 4 (right) 3(left) 1 (right) 2 (left)
    array2=[Element(4, 1), Element(3, -1), Element(1, 1), Element(2, -1)]
    permutation2=Permutation(array2)
    print("START PERM 2")
    print(permutation2.array[0].value)
    print(permutation2.array[0].direction)
    print(permutation2.array[1].value)
    print(permutation2.array[1].direction)
    print(permutation2.array[2].value)
    print(permutation2.array[2].direction)
    print(permutation2.array[3].value)
    print(permutation2.array[3].direction)

def testIsMobile():
    # first array: 1 (left) False 2 (right) False 3 (left) True 4(right) False
    array1=[Element(1, -1), Element(2, 1), Element(3, -1), Element(4, 1)]
    permutation=Permutation(array1)

    # second array: 4 (right) 3(left) 1 (right) 2 (left)
    array2=[Element(4, 1), Element(3, -1), Element(1, 1), Element(2, -1)]
    permutation2=Permutation(array2)

    # false
    print(permutation.isMobile(0))

    # false
    print(permutation.isMobile(1))

    #true
    print(permutation.isMobile(2))

    #false
    print(permutation.isMobile(3))

    print("START PERM 2")
    # element 0 is mobile
    print(permutation2.isMobile(0))

    # element 1 is not mobile
    print(permutation2.isMobile(1))

    # element 2 is not mobile
    print(permutation2.isMobile(2))

    # element 2 is mobile
    print(permutation2.isMobile(3))

def testAnyMobile():
    # first array: 1 (left) False 2 (right) False 3 (left) True 4(right) False
    array1=[Element(1, -1), Element(2, 1), Element(3, -1), Element(4, 1)]
    permutation=Permutation(array1)

    # second array: 4 (right) 3(left) 1 (right) 2 (left)
    array2=[Element(4, 1), Element(3, -1), Element(1, 1), Element(2, -1)]
    permutation2=Permutation(array2)

    
    # true
    print(permutation.anyMobile())

    # there is a mobile element
    print(permutation2.anyMobile())

def testLargestMobile():

    # first array: 1 (left) False 2 (right) False 3 (left) True 4(right) False
    array1=[Element(1, -1), Element(2, 1), Element(3, -1), Element(4, 1)]
    permutation=Permutation(array1)

    # second array: 4 (right) 3(left) 1 (right) 2 (left)
    array2=[Element(4, 1), Element(3, -1), Element(1, 1), Element(2, -1)]
    permutation2=Permutation(array2)

    print(permutation.largestMobile())

    print(permutation2.largestMobile())

def testNextPermutation():
    # first array: 1 (left) False 2 (right) False 3 (left) True 4(right) False
    array1=[Element(1, -1), Element(2, 1), Element(3, -1), Element(4, 1)]
    permutation=Permutation(array1)

    # second array: 4 (right) 3(left) 1 (right) 2 (left)
    array2=[Element(4, 1), Element(3, -1), Element(1, 1), Element(2, -1)]
    permutation2=Permutation(array2)
    
    print(permutation.nextPermutation().array)
    print(permutation2.nextPermutation().array)

    # second array: 4 (right) 3(left) 1 (right) 2 (left)
    array2=[Element(4, 1), Element(3, -1), Element(1, 1), Element(2, -1)]
    permutation2=Permutation(array2)

def testCompiled():
    testPermInitializer()
    testIsMobile()
    testAnyMobile()
    testLargestMobile()
    testNextPermutation()
    
def permute(n):
    
    # generate array
    permuteArray=[]
    permutationArray=[]

    # makes array of numbers
    for i in range (1, n+1):
        permuteArray.append(i)

    # makes array of elements
    for element in permuteArray:
        el=Element(element,-1)
        permutationArray.append(el)
        
    permutation=Permutation(permutationArray)
    returnArray=[permutation]

    # while there are still permutations to be found
    nextPerm=permutation.nextPermutation()
    while nextPerm.anyMobile():
        returnArray.append(nextPerm)
        nextPerm=nextPerm.nextPermutation()
        
        

        
    return returnArray


def test():
    permute(3)
    permute(4)
    
    

    
    

