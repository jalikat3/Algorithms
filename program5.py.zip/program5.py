'''
    
    program5.py
    Jali Purcell
    11/8/21- v. 2
    For program 5 of Algorithms
    

    CLASSES

        Node-represents a node on a binary search tree. Contains
        data, a pointer to a left node, and a pointer to a right node.
        Initially, the node has none for left and right, until more
        nodes are added onto the tree it's in.

        Tree-contains the structure for a binary search tree. Contains
        a root node, which is initialized as None. A root node is given when
        a node is added (using the add method) to the tree. 

    METHODS
'''

class Node():
    def __init__(self,data):
        self.data=data
        self.left=None
        self.right=None
        
class Tree():
    def __init__(self):
        self.root=None

    def getRoot(self):
        return self.root

    def add(self,value):
        if(self.root==None):
            self.root=Node(value)
        else:
            self.addNode(value,self.root)

    # adds a node to a binary search tree
    def addNode(self,value, node):
        if value<node.data:
            if(node.left is None):
                node.left=Node(value)
            else:
                self.addNode(value,node.left)
        else:
            if(node.right is None):
                node.right=Node(value)
            else:
                self.addNode(value,node.right)

    # print in order
    def printInOrderTree(self):
        if self.root is not None:
          print(self.printTreeFromNode(self.root))

    def printTreeFromNode(self,node):
        
        if node is not None:
            left=[]
            right=[]
            
            if(node.left!=None):
                left=self.printTreeFromNode(node.left)
            if(node.right!=None):
                right=self.printTreeFromNode(node.right)
                
            array=[]
            for item in left:
                array.append(item)
            array.append(node.data)
            for item in right:
                array.append(item)
            return array
        
        return []

        # old function
        
        #self.printTreeFromNode(node.left)
        #print(str(node.data)
        #self.printTreeFromNode(node.right)

    # print pre-order 

    def printPreOrderTree(self):
        if self.root is not None:
          print(self.printPreTreeFromNode(self.root))
      
    def printPreTreeFromNode(self,node):
        if node is not None:

            left=[]
            right=[]
            array=[]
            
            array.append(node.data)
            
            if(node.left!=None):
                left=self.printPreTreeFromNode(node.left)
            if(node.right!=None):
                right=self.printPreTreeFromNode(node.right)
                
            for item in left:
                array.append(item)
                
            for item in right:
                array.append(item)
                
            return array
        
        return []
    
            #original function for pre-order
    
            #print(str(node.data))
            #self.printPreTreeFromNode(node.left)
            #self.printPreTreeFromNode(node.right)

    # print post-order
    # modification: print for printing list

    def printPostOrderTree(self):
        if self.root is not None:
          print(self.printPostTreeFromNode(self.root))
      
    def printPostTreeFromNode(self,node):
        if node is not None:

            left=[]
            right=[]
            array=[]
            
            if(node.left!=None):
                left=self.printPostTreeFromNode(node.left)
            if(node.right!=None):
                right=self.printPostTreeFromNode(node.right)
                
            for item in left:
                array.append(item)    
            for item in right:
                array.append(item)
            array.append(node.data)
                
            return array
        
        return []
            
            #self.printPostTreeFromNode(node.left)
            #self.printPostTreeFromNode(node.right)
            #print(str(node.data))

    def printCountNodes(self):
        if self.root is not None:
          print(self.countNodes(self.root))
          
    def countNodes(self,node):
      if node is None:
        return 0
      else:
        return self.countNodes(node.right)+self.countNodes(node.left)+1


            

    

def main():

    # TEST 1
    tree=Tree()
    array=[5,3,4,9,1,6]
    print("Given "+str(array))
    for value in array:
        tree.add(value)
    print("In order")
    tree.printInOrderTree()
    print("")
    print("Pre order")
    tree.printPreOrderTree()
    print("")
    print("Post order")
    tree.printPostOrderTree()
    print("")
    print("Number of nodes: ")
    tree.printCountNodes()
    print("")

    # TEST 2
    tree2=Tree()
    array2=[8,3,1,10,6,4,7,14,13]
    print("Given "+str(array))
    for value in array2:
        tree2.add(value)
    print("In order: ")
    tree2.printInOrderTree()
    print("")
    print("Pre order: ")
    tree2.printPreOrderTree()
    print("")
    print("Post order: ")
    tree2.printPostOrderTree()
    print("")
    print("Number of nodes: ")
    tree2.printCountNodes()

    
    

    
    


